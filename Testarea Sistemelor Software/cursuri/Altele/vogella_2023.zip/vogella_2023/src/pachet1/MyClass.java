package pachet1;

public class MyClass {
    public int multiply(int a, int b) {
        return a * b;
    }
}
