const express=require('express');  
const fs=require('fs'); 
app=express();

app.use('/post',express.urlencoded({extended:false}));

valori=[
	{
		identificator:"a",
		valoare:14
	},
	{
		identificator:"b",
		valoare:10
	},
	{
		identificator:"c",
		valoare:12
	},
	{
		identificator:"d",
		valoare:10
	},
	{
		identificator:"e",
		valoare:10
	},
	{
		identificator:"f",
		valoare:10
	},
	{
		identificator:"g",
		valoare:10
	}
]
app.get("/ex2.html", function(req,res){
        console.log(__dirname);
	res.sendFile(__dirname+"/LAB11/ex2.html");
});

fs.writeFileSync("operatii.json",JSON.stringify([]));

         
app.post("/post",function(req,res){
           var v1,v2;
           var operatii = fs.readFileSync("operatii.json"); //array JSON
           var vector=JSON.parse(operatii); //array JS
           
           for(val of valori) { if(val.identificator == req.body.id1) {v1=val.valoare;}
                                if (val.identificator == req.body.id2) {v2=val.valoare;}
                              }
            
           switch(req.body.operatie) {
          
           case "adunare":

           simbol='+';
           rezultat=v1+v2;

           break;
          
           case "scadere":

           simbol='-';
           rezultat=v1-v2;

           break;
    
             }
           
           res.status(200);
           ob={};                
           ob[req.body.id1]=v1; ob[req.body.id2]=v2;  ob[req.body.operatie]= rezultat;
           vector.push(ob);
           fs.writeFileSync("operatii.json",JSON.stringify(vector));
           res.end(v1 + simbol + v2 + ' = ' + rezultat);
});

app.listen(8010);
console.log("Serverul a pornit");
