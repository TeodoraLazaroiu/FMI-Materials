const express=require('express');
const fs=require('fs');
app=express();

app.use('/post', express.urlencoded({extended:false}));
app.use(express.static("LAB11")); 


app.get("/ex1", function(req,res){ //la cereri get catre calea "ex1" intoarce continutul fisierul ex1.html
        res.sendFile(__dirname+ "/LAB11/ex1.html");
	//res.sendFile("ex1.html", {root: './LAB11'});
});

/*
app.get("/get", function(req,res){
        var date = fs.readFileSync("persoane.json"); //citim datele din fisierul JSON persoane.json (string JSON)
        var persoane = JSON.parse(date); //le transformam in obiect JavaScript
        res.status(200);
        res.write('<html><body><ol>');
        for(a of persoane) { if(a[req.query.tip]==req.query.cuvant) res.write('<li>' + a.nume + ' ' +  a.prenume + '</li>');} 
	res.write('</ol></body></html>');
	res.end();
});
*/

/*app.post("/post", function(req,res){
        var date = fs.readFileSync("persoane.json"); //citim datele din fisierul JSON persoane.json (string JSON)
        var persoane = JSON.parse(date); //le transformam in obiect JavaScript
        res.status(200);
        res.write('<html><body><ol>');
        for(a of persoane) { if(a[req.body.tip]==req.body.cuvant) res.write('<li>' + a.nume + ' ' +  a.prenume + '</li>');} 
	res.write('</ol></body></html>');
	res.end();
});
*/


app.post("/post", function(req,res){

        fs.readFile("persoane.json", function(err, date) { 
         if(err) throw err;   //citim datele din fisierul JSON persoane.json (string JSON)
        var persoane = JSON.parse(date); //le transformam in obiect JavaScript
        res.status(200);
        res.write('<html><body>');
        console.log("mesaj_2");
        for(a of persoane) { if(a[req.body.tip]==req.body.cuvant) res.write('<p>' + a.nume + ' ' +  a.prenume + '</p>');} 
	res.write('</body></html>');
	res.end();});
        console.log("mesaj_3");

});


app.listen(4000);
console.log("Serverul a pornit");
