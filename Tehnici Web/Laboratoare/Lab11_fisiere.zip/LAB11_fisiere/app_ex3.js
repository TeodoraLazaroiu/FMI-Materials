var express = require('express');  
var app = express();   
var nodemailer = require('nodemailer');   //folosirea modulului nodemailer

app.use(express.static('LAB11')); 

app.use('/mail',express.urlencoded({extended:true}));

app.post('/mail', function(req,res){

var adresa=req.body.mail;
var subiect=req.body.subiect;
var mesaj=req.body.message;

res.send("Am trimis mail la adresa " + adresa);

var transporter = nodemailer.createTransport({         //face autentificarea
  service: 'gmail',
  auth: {
    user: 'my.mail.node@gmail.com',
    pass: 'nodemailer'
  }
// tls:{rejectUnauthorized:false}

});

var mailOptions = {                                       //optiunile mesajului
  from: 'my.mail.node@gmail.com',
  to: adresa,
  subject: subiect ,
  text: mesaj
};

transporter.sendMail(mailOptions, function(error, info){              //trimite mail
  if (error) {
    console.log(error);
  } else {
    console.log('Mail trimis: ' + info.response);
  }
});

});

app.listen(8030, function() {console.log('serverul asculta pe portul 8030')});
