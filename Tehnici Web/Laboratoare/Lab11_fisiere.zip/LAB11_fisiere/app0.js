const express = require('express');
const app = express();

app.use('/post', express.urlencoded({extended:true})); 

app.use(express.static('LAB11'));

app.get('/abc', function(req, res) {
 console.log(req.query);
 res.send('Ati citit cuvantul ' + req.query.cuvant + ' limba selectata: ' + req.query.limba);});


app.post('/post', function(req, res) {
 
 console.log(req.body);
 res.send('Ati citit cuvantul ' + req.body.cuvant + ' in limba ' + req.body.limba);});



app.get('/', function(req, res) {
 console.log(req.query);
 res.send("Buna, ce mai faci?");
 
})


app.get('/get', function(req, res) {
 console.log(req.query);
 res.send("Salut!");
 
})


app.post('/submit-data', function (req, res) {
    res.send('POST Request');
});


app.post('/post', function(req, res) {
console.log(req.body);
  
res.send("Buna, ce mai faci?");
 
})

app.listen(5000, function() {console.log('listening')})
